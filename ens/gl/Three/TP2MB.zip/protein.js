var renderer;
var scene;
var camera;
var objects;
var boundingbox;
var light;


var noyau = new THREE.Group();
var golgi = new THREE.Group();
var ribosome = new THREE.Group();
var chloroplaste = new THREE.Group();
var reticulum = new THREE.Group();
var vacuole = new THREE.Group();
var mitochondrie = new THREE.Group();
var plasmodesme = new THREE.Group();

var textCO2 = new THREE.Object3D()
var textPEPC = new THREE.Object3D();
var textMalate = new THREE.Object3D();

var co2 = new THREE.Group();
var pepc = new THREE.Group();
var oa = new THREE.Group();
var am = new THREE.Group();


function render() {
    requestAnimationFrame( render );
    renderer.render( scene, camera );
}

//Fonction permettant de visualiser la cellule dans sa totalite
function showFront(objectCopy) {
    if (objectCopy !== undefined) objectCopy.rotation.z =  0;
    camera.position.z = 0;
    camera.position.y = -0.4*sceneRadiusForCamera;
    camera.position.x = 0.7*sceneRadiusForCamera;
    light.position.set(4*sceneRadiusForCamera, -2*sceneRadiusForCamera,0);
    camera.lookAt(scene.position);
}

//Fonction permettant de positionner la cellule à l'origine de la scene
function resetObjectPosition(objectCopy){
    var size = new THREE.Vector3();
    size.x = boundingbox.max.x - boundingbox.min.x;
    size.y = boundingbox.max.y - boundingbox.min.y;
    size.z = boundingbox.max.z - boundingbox.min.z;


    objectCopy.position.x = -boundingbox.min.x - size.x/2;
    objectCopy.position.y = -boundingbox.min.y - size.y/2;
    objectCopy.position.z = -boundingbox.min.z - size.z/2;
    if (objectCopy !== undefined) objectCopy.rotation.z =  0;

}

//Fonction permettant de creer des groupes (=ensembles d'objets)
//representant les differents compartiments cellulaires
//vacuole, reticulum, etc
function groupCellComponents(object) {
    boundingbox = new THREE.Box3();
    boundingbox.setFromObject(object);

    sceneRadiusForCamera = Math.max(
        boundingbox.max.y - boundingbox.min.y,
        boundingbox.max.z - boundingbox.min.z,
        boundingbox.max.x - boundingbox.min.x
    )/2 * (1 + Math.sqrt(5)) ;
    showFront(object);
    resetObjectPosition(object);
    object.rotation.y = Math.PI/2;
    object.traverse( function(child) {
        if (child instanceof THREE.Mesh) {
            child.castShadow = true;
            child.receiveShadow = true;
            child.rotation.y = Math.PI/2;
            switch (child.material.id) {
            case 10:
                noyau.add(child.clone());
                break;
            case 11:
                noyau.add(child.clone());
                break;
            case 12:
                noyau.add(child.clone());
                break;
            case 13:
                noyau.add(child.clone());
                break;
            case 14:
                golgi.add(child.clone());
                break;
            case 15:
                reticulum.add(child.clone());
                break;
            case 16:
                ribosome.add(child.clone());
                break;
            case 17:
                vacuole.add(child.clone());
                break;
            case 19:
                chloroplaste.add(child.clone());
                break;
            case 21:
                mitochondrie.add(child.clone());
                break;
            case 9:
                scene.add(child.clone());
                break;
            }
        }
    });
}


//Fonction permettant de creer le texte
function initFont() {
    var loader = new THREE.FontLoader();

    loader.load( 'fonts/helvetiker_regular.typeface.json', function ( font ) {
        var font = {
		    font: font,
		    size: 30,
		    height: 10,
		    curveSegments: 12,
		    bevelEnabled: true,
		    bevelThickness: 1,
		    bevelSize: 2,
		    bevelSegments: 12
	    };
	    //TODO
        //Creer les objets textes avec le nom des molecules (CO2, PEPC, Malate)
        //Avec la classe TextGeometry
        //Et les positionner au niveau de leurs molecules respectives
    } );
}


//Fonction retournant un nombre aleatoire dans l'intervalle [min;max]
function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}


//Fonction permettant de creer les molecules de CO2, PEPC et Malate
function createMoleculeModels() {
    //TODO
    //Creer les differentes molecules de geometrie simple (Sphere, Box...)
    //Positionner les molecules dans la scene a l'aide de THREE.Box3()
}

//Fonction permettant d'initialiser les trajectoires des molecules
function createPaths() {
    //TODO
    //1. Initialiser les trajectoires des mol de CO2 vers les mol de PEPC
    //A l'aide de la classe THREE.CatmullRomCurve3
    //2. Faire de meme pour les trajectoires des mol de Malate vers la vacuole
    //3. Stocker les chemins dans 2 tableaux differents
}



//Fonction permettant l'animation
//Deplacement des molecules+reactions
//Apparition du texte
function animate() {
    requestAnimationFrame(animate);
    //TODO
    //1. Deplacer les molecules de CO2 vers les mol de PEPC
    //En suivant les courbes definies par createPaths()
    //2. Faire apparaitre les molecules de Malate
    //Les deplacer dans la vacuole
    //3. Faire apparaitre la reaction CO2+PEPC=>Malate
    //A l'aide de THREE.ArrowHelper
}


//Fonction principale permettant de charger le modele de la cellule (fichier .obj)
function loadCell() {
    var mtlLoader = new THREE.MTLLoader();
    mtlLoader.setTexturePath( 'models/' );
    mtlLoader.setPath( 'models/' );
    var url = "cell2.mtl";
    mtlLoader.load( url, function( materials ) {

        materials.preload();

        var objLoader = new THREE.OBJLoader();
        objLoader.setMaterials( materials );
        objLoader.setPath( 'models/' );
        objLoader.load( 'cell2.obj', function ( object ) {
            groupCellComponents(object);
            createMoleculeModels();
            createPaths();
            animate();
            initFont();
        }, function ( xhr ) {
	        console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );
        },
                        function ( error ) {
	                        console.log( 'An error happened' );
                        }
                      );

    });
}

function main() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, 1, 0.1, 100000);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(800, 800);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    var controls = new THREE.OrbitControls(camera);
    renderer.setClearColor(new THREE.Color(1,1.0,1.0),1.0);
    renderer.clear();
    document.body.appendChild( renderer.domElement );



    scene.add( chloroplaste  );
    scene.add( reticulum );
    scene.add(noyau);
    scene.add(golgi);
    scene.add(ribosome);
    scene.add(vacuole);
    scene.add(mitochondrie);
    scene.add(plasmodesme);

    loadCell();

    light = new THREE.PointLight( 0xffffff, 0.9, 0, 2 );
    //Decommenter pour avoir des ombres portees
    //light.castShadow = true;
    light.shadow.mapSize.width = 2048;
    light.shadow.mapSize.height = 2048;
    light.shadow.camera.near = 0.1;
    light.shadow.camera.far = 1000;
    scene.add(light);

    var light2=new THREE.AmbientLight(0xffffff,0.3);
    scene.add(light2);

    render();
}
