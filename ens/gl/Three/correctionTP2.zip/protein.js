var renderer;
var scene;
var camera;
var objects;
var boundingbox;
var light;


var noyau = new THREE.Group();
var golgi = new THREE.Group();
var ribosome = new THREE.Group();
var chloroplaste = new THREE.Group();
var reticulum = new THREE.Group();
var vacuole = new THREE.Group();
var mitochondrie = new THREE.Group();
var plasmodesme = new THREE.Group();

var textCO2 = new THREE.Object3D()
var textPEPC = new THREE.Object3D();
var textMalate = new THREE.Object3D();

var co2 = new THREE.Group();
var pepc = new THREE.Group();
var oa = new THREE.Group();
var am = new THREE.Group();
var curvePaths, curvePathsVacuole;

var numberOfMol = 10;
var maxNumberPoints = 100;
var indexFirst = 0;
var indexSecond = 0;


function render() {
    requestAnimationFrame( render );
    renderer.render( scene, camera );
}

function initFont() {
    var loader = new THREE.FontLoader();

    loader.load( 'fonts/helvetiker_regular.typeface.json', function ( font ) {
        var font = {
		    font: font,
		    size: 30,
		    height: 10,
		    curveSegments: 12,
		    bevelEnabled: true,
		    bevelThickness: 1,
		    bevelSize: 2,
		    bevelSegments: 12
	    };
	    var geometry = new THREE.TextGeometry( 'CO2', font);
        var material = new THREE.MeshPhongMaterial({color : 0xff0000, transparent:true, opacity:0.7});
        textCO2 = new THREE.Mesh(geometry, material);
        var boco2 = new THREE.Box3();
        boco2.setFromObject(co2);
        textCO2.position.set(boco2.getCenter().x, boco2.getCenter().y, boco2.getCenter().z);
        textCO2.rotation.y = Math.PI/2;


        var geometryP = new THREE.TextGeometry( 'PEPC', font);
        var materialP = new THREE.MeshPhongMaterial({color : 0x00ff00, transparent:true, opacity:0.7});
        textPEPC = new THREE.Mesh(geometryP, materialP);
        var bopepc = new THREE.Box3();
        bopepc.setFromObject(pepc);
        textPEPC.position.set(bopepc.getCenter().x+100, bopepc.getCenter().y, bopepc.getCenter().z);
        textPEPC.rotation.y = Math.PI/2;

        var geometryM = new THREE.TextGeometry( 'Malate', font);
        var materialM = new THREE.MeshPhongMaterial({color : 0x0000ff, transparent:true, opacity:0.7});
        textMalate = new THREE.Mesh(geometryM, materialM);
        var boMalate = new THREE.Box3();
        boMalate.setFromObject(am);
        textMalate.position.set(boMalate.getCenter().x+100, boMalate.getCenter().y, boMalate.getCenter().z);
        textMalate.rotation.y = Math.PI/2;
    } );
}

function showFront(objectCopy) {
    if (objectCopy !== undefined) objectCopy.rotation.z =  0;
    camera.position.z = 0;
    camera.position.y = -0.4*sceneRadiusForCamera;
    camera.position.x = 0.7*sceneRadiusForCamera;
    light.position.set(4*sceneRadiusForCamera, -2*sceneRadiusForCamera,0);
    camera.lookAt(scene.position);
}

function resetObjectPosition(objectCopy){
    var size = new THREE.Vector3();
    size.x = boundingbox.max.x - boundingbox.min.x;
    size.y = boundingbox.max.y - boundingbox.min.y;
    size.z = boundingbox.max.z - boundingbox.min.z;

    // Repositioning object
    objectCopy.position.x = -boundingbox.min.x - size.x/2;
    objectCopy.position.y = -boundingbox.min.y - size.y/2;
    objectCopy.position.z = -boundingbox.min.z - size.z/2;
    if (objectCopy !== undefined) objectCopy.rotation.z =  0;

}

function groupCellComponents(object) {
    boundingbox = new THREE.Box3();
    boundingbox.setFromObject(object);

    sceneRadiusForCamera = Math.max(
        boundingbox.max.y - boundingbox.min.y,
        boundingbox.max.z - boundingbox.min.z,
        boundingbox.max.x - boundingbox.min.x
    )/2 * (1 + Math.sqrt(5)) ; // golden number to beautify display
    showFront(object);
    resetObjectPosition(object);
    object.rotation.y = Math.PI/2;
    object.traverse( function(child) {
        if (child instanceof THREE.Mesh) {
            child.castShadow = true;
            child.receiveShadow = true;
            child.rotation.y = Math.PI/2;
            switch (child.material.id) {
            case 10:
                noyau.add(child.clone());
                break;
            case 11:
                noyau.add(child.clone());
                break;
            case 12:
                noyau.add(child.clone());
                break;
            case 13:
                noyau.add(child.clone());
                break;
            case 14:
                golgi.add(child.clone());
                break;
            case 15:
                reticulum.add(child.clone());
                break;
            case 16:
                ribosome.add(child.clone());
                break;
            case 17:
                vacuole.add(child.clone());
                break;
            case 19:
                chloroplaste.add(child.clone());
                break;
            case 21:
                mitochondrie.add(child.clone());
                break;
            case 9:
                scene.add(child.clone());
                break;

            }
        }
    });
}

function loadCell() {
    var mtlLoader = new THREE.MTLLoader();
    mtlLoader.setTexturePath( 'models/' );
    mtlLoader.setPath( 'models/' );
    var url = "cell2.mtl";
    mtlLoader.load( url, function( materials ) {

        materials.preload();

        var objLoader = new THREE.OBJLoader();
        objLoader.setMaterials( materials );
        objLoader.setPath( 'models/' );
        objLoader.load( 'cell2.obj', function ( object ) {
            groupCellComponents(object);
            createMoleculeModels();
            createPaths();
            animate();
            initFont();
        }, function ( xhr ) {
	        console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );
        },
                        // called when loading has errors
                        function ( error ) {
	                        console.log( 'An error happened' );
                        }
                      );

    });
}


function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}


function createMoleculeModels() {
    var geometry = new THREE.SphereGeometry(7,32,32);
    var mat = new THREE.MeshPhongMaterial({color : 0xff0000});
    var co2mol = new THREE.Mesh(geometry, mat);
    bo = new THREE.Box3();
    bo.setFromObject(golgi);
    for (var i=0; i < numberOfMol; i++) {
        var mol = co2mol.clone();
        mol.position.x = getRandomArbitrary(boundingbox.getCenter().x+100, boundingbox.max.x);
        mol.position.y = getRandomArbitrary(boundingbox.getCenter().y+100, boundingbox.max.y);
        mol.position.z = getRandomArbitrary(boundingbox.getCenter().z+100, boundingbox.max.z);
        co2.add(mol);

    }
    scene.add(co2);

    var geometryp = new THREE.BoxGeometry(7,7,7);
    var matp = new THREE.MeshPhongMaterial({color : 0x00ff00});
    var pepcmol = new THREE.Mesh(geometryp, matp);

    for (var i=0; i < numberOfMol; i++) {
        var mol = pepcmol.clone();

        mol.position.x = getRandomArbitrary(bo.min.x, bo.max.x);
        mol.position.y = getRandomArbitrary(bo.min.y, bo.max.y);
        mol.position.z = getRandomArbitrary(bo.min.z, bo.max.z);
        pepc.add(mol);

    }
    scene.add(pepc);
}


function createPaths() {
    curvePaths = new THREE.CurvePath();
    for (var i = 0; i < numberOfMol; i++) {
        var curve = new THREE.CatmullRomCurve3([co2.children[i].position,pepc.children[i].position]);
        curvePaths.add(curve);
    }
}

function createPathToVacuole() {
    curvePathsVacuole = new THREE.CurvePath();
    var bov = new THREE.Box3();
    bov.setFromObject(vacuole);


    for (var i = 0; i < numberOfMol; i++) {
        var vec = new THREE.Vector3(getRandomArbitrary(bov.min.x, bov.max.x-10),
                                    getRandomArbitrary(bov.min.y, bov.max.y-10),
                                    getRandomArbitrary(bov.min.z, bov.max.z-10));
        var curve = new THREE.CatmullRomCurve3([am.children[i].position,vec]);
        curvePathsVacuole.add(curve);
    }
}

var first=true;
function animate() {
    requestAnimationFrame(animate);
    if (indexFirst <= maxNumberPoints) {
        scene.add(textCO2);
        scene.add(textPEPC);
        var curves = curvePaths.curves;
        for (var ind = 0; ind < numberOfMol; ind++) {
            var co2m = co2.children[ind];
            var pepcm = pepc.children[ind];
            var curve = curves[ind];
            var points = curve.getPoints(maxNumberPoints);
            var ipep = points.length - 1 - indexFirst;
            co2m.position.set(points[indexFirst].x, points[indexFirst].y, points[indexFirst].z);
            //pepcm.position.set(points[ipep].x, points[ipep].y, points[ipep].z);
        }
        indexFirst++;
    }
    else {

        if (first) {
            for (var i = 0; i < numberOfMol; i++) {
                var child = co2.children[i];
                var clone = child.clone();
                clone.material = new THREE.MeshPhongMaterial({color: 0x0000ff});
                am.add(clone);
            }
            scene.add(am);
            scene.remove(co2);
            scene.remove(pepc);
            scene.add(textMalate);
            scene.remove(textCO2);
            scene.remove(textPEPC);
            first = false;
            createPathToVacuole();
        }
        else if (indexSecond < maxNumberPoints){
            var curveVac = curvePathsVacuole.curves;
            for (var ind = 0; ind < numberOfMol; ind++) {
                var amm = am.children[ind];
                var curvePath = curveVac[ind];
                var points = curvePath.getPoints(maxNumberPoints);
                amm.position.set(points[indexSecond].x, points[indexSecond].y, points[indexSecond].z);
            }
            indexSecond++;
        }
        else {
            scene.add(textPEPC);
            scene.add(textCO2);
            var boMalate = new THREE.Box3();
            boMalate.setFromObject(am);
            textMalate.position.set(boMalate.getCenter().x+100, boMalate.getCenter().y, boMalate.getCenter().z);

            var dir = textMalate.position.clone().sub(textCO2.position.clone());
            var origin = textCO2.position;
            var length = dir.length();
            var hex = 0xcccccc;
            var arrowCO2  = new THREE.ArrowHelper( dir.normalize(), origin, length, hex, 0.1*length );
            scene.add(arrowCO2);

            var dirP = textMalate.position.clone().sub(textPEPC.position.clone());
            var originP = textPEPC.position;
            var lengthP = dirP.length();
            var arrowPEPC  = new THREE.ArrowHelper( dirP.normalize(), originP, lengthP, hex, 0.1*length );
            scene.add(arrowPEPC);
        }
    }
}

function main() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, 1, 0.1, 100000);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(800, 800);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    var controls = new THREE.OrbitControls(camera);
    renderer.setClearColor(new THREE.Color(1,1.0,1.0),1.0);
    renderer.clear();
    document.body.appendChild( renderer.domElement );



    scene.add( chloroplaste  );
    scene.add( reticulum );
    scene.add(noyau);
    scene.add(golgi);
    scene.add(ribosome);
    scene.add(vacuole);
    scene.add(mitochondrie);
    scene.add(plasmodesme);

    loadCell();

    light = new THREE.PointLight( 0xffffff, 0.9, 0, 2 );
    //light.castShadow = true;
    //Set up shadow properties for the light
    light.shadow.mapSize.width = 2048;
    light.shadow.mapSize.height = 2048;
    light.shadow.camera.near = 0.1;
    light.shadow.camera.far = 1000;
    scene.add(light);

    var light2=new THREE.AmbientLight(0xffffff,0.3);
    scene.add(light2);


    render();
}
