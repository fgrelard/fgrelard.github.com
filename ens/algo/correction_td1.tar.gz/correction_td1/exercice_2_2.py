from exercice_2_0 import *

def creer_tableau():
    """
    Créer un tableau

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> t = creer_tableau()
        >>> t
        [0]
    """
    return creer_pile()

def inserer_element( T, id_e, e ):
    """
    Insère un élément 'e' à la position 'id' de 'T'.

    Complexité : 
        pire cas : O(id_e) = O(n)
        meilleur cas : omega(id_e) = omega(1)

    où n = len( T )

    Exemples :
        >>> t = creer_tableau()
        >>> inserer_element( t, 0, 42 )
        >>> t
        [42, 1]
        >>> inserer_element( t, 0, 43 )
        >>> t
        [42, 43, 2]
        >>> inserer_element( t, 2, 44 )
        >>> t
        [44, 42, 43, 3]
        >>> inserer_element( t, 2, 45 )
        >>> t
        [44, 45, 42, 43, 4]
    """
    pile = creer_pile()
    for i in range( id_e ):
        empiler( pile, depiler( T ) )
    empiler( T, e )
    for i in range( id_e ):
        empiler( T, depiler( pile ) )

def  supprimer_element( T, id_e ):
    """
    Supprime un élément situé à la position 'id_e' de 'T'

    Complexité : 
        pire cas : O(id_e) = O(n)
        meilleur cas : omega(id_e) = omega(1)

    où n = len( T )

    Exemples :
        >>> t = creer_tableau()
        >>> inserer_element( t, 0, 42 )
        >>> inserer_element( t, 0, 43 )
        >>> inserer_element( t, 2, 44 )
        >>> inserer_element( t, 2, 45 )
        >>> t
        [44, 45, 42, 43, 4]
        >>> supprimer_element( t, 2 )
        >>> t
        [44, 42, 43, 3]
        >>> supprimer_element( t, 0 )
        >>> t
        [44, 42, 2]
        >>> supprimer_element( t, 1 )
        >>> t
        [42, 1]
    """
    pile = creer_pile()
    for i in range( id_e ):
        empiler( pile, depiler( T ) )
    depiler( T )
    for i in range( id_e ):
        empiler( T, depiler( pile ) )

def remplacer_element( T, id_e, e ):
    """
    Supprime l'élément situé à la position 'id_e' par l'élément 'e' dans 'T'.

    Complexité : 
        pire cas : O(id_e) = O(n)
        meilleur cas : omega(id_e) = omega(1)

    où n = len( T )

        Exemples :
            >>> t = creer_tableau()
            >>> inserer_element( t, 0, 42 )
            >>> inserer_element( t, 0, 43 )
            >>> inserer_element( t, 2, 44 )
            >>> inserer_element( t, 2, 45 )
            >>> t
            [44, 45, 42, 43, 4]
            >>> remplacer_element( t, 2, 10 )
            >>> t
            [44, 10, 42, 43, 4]
            >>> remplacer_element( t, 0, 11 )
            >>> t
            [44, 10, 42, 11, 4]
            >>> remplacer_element( t, 3, 12 )
            >>> t
            [12, 10, 42, 11, 4]
    """
    pile = creer_pile()
    for i in range( id_e ):
        empiler( pile, depiler( T ) )
    depiler( T )
    empiler( T, e )
    for i in range( id_e ):
        empiler( T, depiler( pile ) )

def obtenir_element( T, id_e ):
    """
    Supprime l'élément situé à la position 'id_e' par l'élément 'e' dans 'T'.

    Complexité : 
        pire cas : O(id_e) = O(n)
        meilleur cas : omega(id_e) = omega(1)

    où n = len( T )

        Exemples :
            >>> t = creer_tableau()
            >>> inserer_element( t, 0, 42 )
            >>> inserer_element( t, 0, 43 )
            >>> inserer_element( t, 2, 44 )
            >>> inserer_element( t, 2, 45 )
            >>> t
            [44, 45, 42, 43, 4]
            >>> obtenir_element( t, 0 )
            43
            >>> obtenir_element( t, 1 )
            42
            >>> obtenir_element( t, 2 )
            45
            >>> obtenir_element( t, 3 )
            44
    """
    pile = creer_pile()
    for i in range( id_e ):
        empiler( pile, depiler( T ) )
    element = depiler( T )
    empiler( T, element )
    for i in range( id_e ):
        empiler( T, depiler( pile ) )
    return element

if __name__ == "__main__":
    import doctest
    doctest.testmod() 

