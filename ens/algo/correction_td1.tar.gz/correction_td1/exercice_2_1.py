from exercice_2 import *

def creer_file():
    """
    Créer et renvoie une file vide.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> f = creer_file()
        >>> f
        [0]
    """
    return creer_pile()

def enfiler( f, element ):
    """
    Enfile un élément 'element' dans la file 'f'.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> f = creer_file()
        >>> enfiler( f, 3 )
        >>> enfiler( f, 4 )
        >>> enfiler( f, 5 )
        >>> enfiler( f, 3 )
        >>> f
        [3, 4, 5, 3, 4]
    """
    empiler( f, element )

def defiler( f ):
    """
    Défile et renvoie le dernier élément de la file 'f'.

    Complexité : 
        pire cas : O(n)
        meilleur cas : omega(n)

    Exemples:
        >>> f = creer_file()
        >>> enfiler( f, 3 )
        >>> enfiler( f, 4 )
        >>> enfiler( f, 5 )
        >>> f
        [3, 4, 5, 3]
        >>> defiler( f )
        3
        >>> f
        [4, 5, 2]
    """
    taille = taille_pile( f )
    pile = creer_pile()
    for i in range( taille-1 ):
        empiler( pile, depiler(f) )
    element = depiler(f)
    for i in range( taille-1 ):
        empiler( f, depiler(pile) )
    return element


if __name__ == "__main__":
    import doctest
    doctest.testmod() 

