import exercice_1

def creer_pile():
    """
    Créer et renvoie une pile vide.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> pile
        [0]
    """
    pile = exercice_1.creer_pile()
    exercice_1.empiler( pile , 0 )
    return pile

def empiler( pile, element ):
    """
    Empile un élément 'element' dans la pile 'pile'.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> empiler( pile, 3 )
        >>> empiler( pile, 4 )
        >>> empiler( pile, 5 )
        >>> empiler( pile, 3 )
        >>> pile
        [3, 4, 5, 3, 4]
    """
    taille = exercice_1.depiler( pile )
    exercice_1.empiler( pile, element )
    exercice_1.empiler( pile, taille+1 )

def depiler( pile ):
    """
    Dépile et renvoie le dernier élément de la pile.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> empiler( pile, 3 )
        >>> empiler( pile, 4 )
        >>> empiler( pile, 5 )
        >>> depiler( pile )
        5
        >>> pile
        [3, 4, 2]
    """
    taille = exercice_1.depiler( pile )
    element = exercice_1.depiler( pile )
    exercice_1.empiler( pile, taille-1 )
    return element

def taille_pile( pile ):
    """
    Renvoie la taille de la pile

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemple:
        >>> pile = creer_pile()
        >>> taille_pile( pile )
        0
        >>> empiler( pile, 3 )
        >>> taille_pile( pile )
        1
        >>> empiler( pile, 4 )
        >>> taille_pile( pile )
        2
        >>> empiler( pile, 5 )
        >>> taille_pile( pile )
        3
    """
    taille = exercice_1.depiler( pile )
    exercice_1.empiler( pile, taille )
    return taille


if __name__ == "__main__":
    import doctest
    doctest.testmod() 

