from exercice_2_0 import *

def creer_dictionnaire():
    """
    Créer et rencoie un dictionnaire

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> d = creer_dictionnaire()
        >>> d
        [0]
    """
    return creer_pile()

def inserer_association( D, cle, valeur ):
    """
    Ajoute une nouvelle association ('cle','valeur') dans le dictionnaire 'D'
    S'il existait déjà une association ('cle',valeur1), alors cette association
    est remplacée par ('cle','valeur').

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples :
        >>> d = creer_dictionnaire()
        >>> inserer_association( d, 3, 42 )
        >>> d
        [42, 3, 2]
        >>> inserer_association( d, 9, 6 )
        >>> d
        [42, 3, 6, 9, 4]
        >>> inserer_association( d, 4, 5 )
        >>> d
        [42, 3, 6, 9, 5, 4, 6]
    """
    empiler( D, valeur )
    empiler( D, cle )

def taille_dictionnaire( D ):
    """
    Retourne la taille du dictionnaire.
    
    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> d = creer_dictionnaire()
        >>> taille_dictionnaire( d )
        0
        >>> inserer_association( d, 3, 42 )
        >>> taille_dictionnaire( d )
        1
        >>> inserer_association( d, 9, 6 )
        >>> taille_dictionnaire( d )
        2
        >>> inserer_association( d, 4, 5 )
        >>> taille_dictionnaire( d )
        3
    """
    return taille_pile( D )//2

def supprimer_association( D, cle ):
    """
    Supprimme toute association de D ayant pour clé 'cle'

    Complexité : 
        pire cas : O(n)
        meilleur cas : omega(1)

        où n = len( D )

    Exemples:
        >>> d = creer_dictionnaire()
        >>> inserer_association( d, 3, 42 )
        >>> inserer_association( d, 9, 6 )
        >>> inserer_association( d, 4, 5 )
        >>> d
        [42, 3, 6, 9, 5, 4, 6]
        >>> supprimer_association( d, 43 )
        >>> d
        [42, 3, 6, 9, 5, 4, 6]
        >>> supprimer_association( d, 9 )
        >>> d
        [42, 3, 5, 4, 4]
        >>> supprimer_association( d, 3 )
        >>> d
        [5, 4, 2]
        >>> supprimer_association( d, 4 )
        >>> d
        [0]
    """
    pile = creer_pile()
    nb_associations = taille_dictionnaire( D )
    for i in range( nb_associations ):
        cle_1 = depiler( D )
        valeur_1 = depiler( D )
        if cle_1 == cle :
            break
        empiler( pile, cle_1 )
        empiler( pile, valeur_1 )
    taille = taille_pile( pile )
    for i in range( taille ):
        empiler( D, depiler( pile ) )

def obtenir_valeur( D, cle ):
    """
    Renvoie la valeur associé au dictionnaire et None sinon.

    Complexité : 
        pire cas : O(n)
        meilleur cas : omega(1)

        où n = len( D )

    Exemples:
        >>> d = creer_dictionnaire()
        >>> inserer_association( d, 3, 42 )
        >>> inserer_association( d, 9, 6 )
        >>> inserer_association( d, 4, 5 )
        >>> d
        [42, 3, 6, 9, 5, 4, 6]
        >>> obtenir_valeur( d, 3 )
        42
        >>> obtenir_valeur( d, 9 )
        6
        >>> obtenir_valeur( d, 4 )
        5
        >>> obtenir_valeur( d, 42 ) is None
        True
    """
    pile = creer_pile()
    nb_associations = taille_dictionnaire( D )
    result = None
    for i in range( nb_associations ):
        cle_1 = depiler( D )
        valeur_1 = depiler( D )
        empiler( pile, cle_1 )
        empiler( pile, valeur_1 )
        if cle_1 == cle :
            result = valeur_1
            break
    taille = taille_pile( pile )
    for i in range( taille ):
        empiler( D, depiler( pile ) )
    return result

def appartient_au_dictionnaire( D, cle ):
    """
    Renvoie vrai si la clé appartient au dictionnaire.

    Complexité : 
        pire cas : O(n)
        meilleur cas : omega(1)

        où n = len( D )

    Exemples:
        >>> d = creer_dictionnaire()
        >>> inserer_association( d, 3, 42 )
        >>> inserer_association( d, 9, 6 )
        >>> inserer_association( d, 4, 5 )
        >>> d
        [42, 3, 6, 9, 5, 4, 6]
        >>> appartient_au_dictionnaire( d, 3 )
        True
        >>> appartient_au_dictionnaire( d, 9 )
        True
        >>> appartient_au_dictionnaire( d, 4 )
        True
        >>> appartient_au_dictionnaire( d, 42 )
        False
    """
    return not( obtenir_valeur( D, cle ) is None )


if __name__ == "__main__":
    import doctest
    doctest.testmod() 
