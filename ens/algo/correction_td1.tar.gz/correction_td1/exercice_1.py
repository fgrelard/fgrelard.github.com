def creer_pile():
    """
    Créer et renvoie une pile vide.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> pile
        []
    """
    return []

def empiler( pile, element ):
    """
    Empile un élément 'element' dans la pile 'pile'.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> empiler( pile, 3 )
        >>> empiler( pile, 4 )
        >>> empiler( pile, 5 )
        >>> empiler( pile, 3 )
        >>> pile
        [3, 4, 5, 3]
    """
    pile.append( element )

def depiler( pile ):
    """
    Dépile et renvoie le dernier élément de la pile.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> pile = creer_pile()
        >>> empiler( pile, 3 )
        >>> empiler( pile, 4 )
        >>> empiler( pile, 5 )
        >>> depiler( pile )
        5
        >>> pile
        [3, 4]
    """
    return pile.pop()

import collections

def creer_file():
    """
    Créer et renvoie une file vide.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> f = creer_file()
        >>> f
        deque([])
    """
    return collections.deque()

def enfiler( f, element ):
    """
    Enfile un élément 'element' dans la file 'f'.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> f = creer_file()
        >>> enfiler( f, 3 )
        >>> enfiler( f, 4 )
        >>> enfiler( f, 5 )
        >>> enfiler( f, 3 )
        >>> f
        deque([3, 4, 5, 3])
    """
    f.append( element )

def defiler( f ):
    """
    Défile et renvoie le dernier élément de la file 'f'.

    Complexité : 
        pire cas : O(1)
        meilleur cas : omega(1)

    Exemples:
        >>> f = creer_file()
        >>> enfiler( f, 3 )
        >>> enfiler( f, 4 )
        >>> enfiler( f, 5 )
        >>> defiler( f )
        3
        >>> f
        deque([4, 5])
    """
    return f.popleft()

if __name__ == "__main__":
    import doctest
    doctest.testmod() 

