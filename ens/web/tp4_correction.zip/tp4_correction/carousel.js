"use strict";

var path = "imgCarrousel/";
var arrayImg = [path+"1.jpg", path+"2.jpg", path+"3.jpg"];
var index = 0;
var interval;

function setupInterval() {
    interval = setInterval(function() {
        changeImage("next", "other");
    }, 2000);
}

function changeImage(event, button="next", type="click") {
    //This helps prevents the timer from changing an
    //image just after clicking
    if (type === "click") {
        clearInterval(interval);
        setupInterval();
    }
    var image = document.getElementById("myImg");
    if (type === "previous") {
        index -= 1;
    }
    else {
        index += 1;
    }
    if (index < 0) {
        index = arrayImg.length-1;
    }
    else if (index > arrayImg.length-1) {
        index = 0;
    }
    var newPath = arrayImg[index];
    image.src = newPath;
}

function setupListeners(event) {
    var previous = document.getElementById("previous");
    var next = document.getElementById("next");
    previous.addEventListener("click", function(event) {
        changeImage(event, "previous");
    });
    next.addEventListener("click", changeImage);
    setupInterval();
}

window.addEventListener("load", setupListeners);
