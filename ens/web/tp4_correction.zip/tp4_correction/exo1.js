"use strict";

function formatText(event) {
    event.target.textContent = "New text in italic and red";
    event.target.style.color = "red";
    event.target.style["font-style"] = "italic";
}

function setupListeners(event) {
    var img = document.getElementById("myImg");
    img.addEventListener("mouseover", function(event) {
        img.src="imgExo1/2.jpg";
    });
    img.addEventListener("mouseout", function(event) {
        img.src="imgExo1/1.jpg";
    });
    var text = document.getElementById("text");
    text.addEventListener("click", formatText);
}

window.addEventListener("load", setupListeners);
